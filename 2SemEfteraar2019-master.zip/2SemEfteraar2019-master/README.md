# 2SemEfteraar2019

Undervisning i JavaScript mv.: Multimediedesigner Andet semester efteråret 2019.

Her vil der med tiden komme boilerplates, dvs. templates som du kan arbejde videre på.

# Billeder og lydfiler

Billeder og lydfiler er fjernet fra denne demo. Du kan selv tilføje passende filer.
