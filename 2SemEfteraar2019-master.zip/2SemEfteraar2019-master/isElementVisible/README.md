Is my element visible
=====================

Use the code sample like this:

~~~~
if (elFllVsbl ( lyd )){ ...
~~~~  

and not like this:

~~~~
if (elFllVsbl ( mySound )){ ...
~~~~

The solution is inspired by an original idea by Bror Arnfast.
