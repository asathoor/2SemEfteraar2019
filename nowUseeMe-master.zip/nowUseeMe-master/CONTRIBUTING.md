If you have ideas please feel free to contribute to the code.
